package zexal.org.kontak;

import android.graphics.Movie;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends  AppCompatActivity {
    private List<android_kontak> kontakList = new ArrayList<>();
    private RecyclerView recyclerView;
    private kontak_adapter mAdapter;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/*        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*/

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        editText = (EditText) findViewById(R.id.search);

        mAdapter = new kontak_adapter(kontakList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);


        prepareMovieData();
    }

    private void prepareMovieData() {
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));
        kontakList.add(new android_kontak("Sukinem", "085852852852"));


        mAdapter.notifyDataSetChanged();
    }
}