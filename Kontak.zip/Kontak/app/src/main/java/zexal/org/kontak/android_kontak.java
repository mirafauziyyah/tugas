package zexal.org.kontak;

/**
 * Created by Ilham on 3/24/2017.
 */

public class android_kontak  {

    private String nama;
    private String nomer;

    public android_kontak (String nama, String nomer)
    {
        this.setNama(nama);
        this.setNomer(nomer);
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    public String getNomer() {
        return nomer;
    }


    public void setNomer(String nomer) {
        this.nomer = nomer;
    }
}
