package zexal.org.kontak;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Ilham on 3/24/2017.
 */

public class kontak_adapter extends   RecyclerView.Adapter<kontak_adapter.MyViewHolder> {

private List<android_kontak> kontakList;

public class MyViewHolder extends RecyclerView.ViewHolder {
    public TextView name, number ;

    public MyViewHolder(View view) {
        super(view);
        name = (TextView) view.findViewById(R.id.nama);
        number = (TextView) view.findViewById(R.id.nomer);
    }
}


    public kontak_adapter(List<android_kontak> kontakList) {
        this.kontakList = kontakList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.kontak_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        android_kontak kontak = kontakList.get(position);
        holder.name.setText(kontak.getNama());
        holder.number.setText(kontak.getNomer());

    }

    @Override
    public int getItemCount() {
        return kontakList.size();
    }
}